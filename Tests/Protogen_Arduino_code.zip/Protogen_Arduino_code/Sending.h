#ifndef KEY_H
#define KEY_H
struct KEY {
public:
    const String NAME;  // User-friendly displayed name of the key
    const unsigned short KEY_VALUE;  // The value to be sent over serial
    KEY* AttachedList;  // Pointer to a list (or array) of other KEY structs

    // Constructor to initialize const members
    KEY(const String& name, unsigned short key, KEY* attachedList = nullptr) : NAME(name), KEY_VALUE(key), AttachedList(attachedList) {}
};

#endif