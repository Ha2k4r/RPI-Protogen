
#include <string.h>
#include "Sending.h"

class Values {
public:
    short SelectedNounEntry = 0;
    short SelectedVerbEntry = 0;
    short Value = 0;

    // Array of pointers instead of objects
    KEY* SelectedKeysInOrder[3] = {
      &ValidNouns[SelectedNounEntry],
      ValidNouns[SelectedNounEntry].AttachedList,
      ValidNouns[SelectedNounEntry].AttachedList->AttachedList
    };

    void UpdateKey(int NounorVerb) {
        KEY* ValidKeys;
        short entry;
        if (NounorVerb == 0){
          entry = SelectedNounEntry;
          ValidKeys = ValidNouns;
          SelectedNounEntry = entry;
        }
        else if(NounorVerb == 1) {
          ValidKeys = MatrixVerb;
          SelectedVerbEntry = entry;
        }
        else {
          Serial.println("Invalid selection as this has not been implemented yet");
          return;
        }
        Serial.println("Max size : ");
        Serial.println((sizeof(ValidNouns) / sizeof(ValidNouns[0])-1));
        Serial.println("Selection : ");
        Serial.println(entry);

        // Update pointers instead of copying entire structs
        //Serial.print("Value: ");
        Serial.println(ValidKeys[entry].NAME);
        
        SelectedKeysInOrder[NounorVerb] = &ValidKeys[entry];

        //SelectedKeysInOrder[1] = ValidNouns[0].AttachedList;
        //SelectedKeysInOrder[2] = ValidNouns[0].AttachedList->AttachedList;
    }
};


// --- BUTTONS ---
ArbitraryButton Noun(NounButtonPin, 0); // Thing to address
ArbitraryButton Verb(VerbButtonPin, 1); // Action
ArbitraryButton Adverb(AdverbButtonPin, 2); // Optional: eventually this will truely use the benifits of real-time math rendering
ArbitraryButton SEND(SENDButtonPin, 3); // Sends input data via Serial

// --- TFT SCREEN ---
#if TFTSCREEN_IS_ACTIVE
  TFTScreen Screen;
#endif

Values Selection;

//  ---   ROTORY ENCODER   ---
//i know my code is bad, its thrown together poorly 
//but this is at the bottom of the page and that shit does need to be declared
void UpdateScreensSelection();

void onRotateCallback(char Operator) {
    int MAX = (sizeof(ValidNouns) / sizeof(ValidNouns[0])-1);
    unsigned short MAXORMIN;
    unsigned short SUB;
    switch (Operator){
      case 'S':
      {
       SUB = Selection.SelectedNounEntry-1;
        MAXORMIN = MAX;
        break;
      }
      case 'A':
      {
        SUB = Selection.SelectedNounEntry+1;
        MAXORMIN = 0;
        break;
      }
      default:{
        Serial.println("Your code is shit. ");
        return;
      }
    };
    if(SUB == UINT16_MAX || SUB > MAX){
      Selection.SelectedNounEntry=MAXORMIN;
      
      Selection.UpdateKey(0);
      UpdateScreensSelection();
    }
    else {
     Selection.SelectedNounEntry = SUB;
     Selection.UpdateKey(0);
     UpdateScreensSelection();
    }
}
RotaryEncoder encoder(ENCODER_CLK, ENCODER_DT, ENCODER_SW, onPress, onLongPress,onRotateCallback);



void setup() {
  Serial.begin(9600);
  encoder.begin();

    #if TFTSCREEN_IS_ACTIVE
      Screen.Initialize();
    #endif
} 

#if TFTSCREEN_IS_ACTIVE
void RespondToChangedButtonStates(){
  //if ()
  for (int i=0; i < 4 ; i++){
        if (updatedValues[i] != 0){
          //if any have changed
          switch (i){
            //Which button has changed
            case 0:
              
              Screen.SelectionMaskUpdate(1, "Noun");
              Screen.SelectionMaskUpdate(2, Selection.SelectedKeysInOrder[0]->NAME);
              updatedValues[i]=0;
              break;
            case 1:
              //Screen.SelectionMaskUpdate(1, "Selection:");
              Screen.SelectionMaskUpdate(1, "Verb");
              updatedValues[i]=0;
              break;
            case 2:
              //Screen.SelectionMaskUpdate(1, "Selection:");
              Screen.SelectionMaskUpdate(1, "Input Mode");
              updatedValues[i]=0;
              break;
            case 3: 
              Screen.SelectionMaskUpdate(1, "send");
              Screen.SelectionMaskUpdate(2, "");
              Screen.SelectionMaskUpdate(4, "");
              updatedValues[i]=0;
              break;
          };
        }
      }
}
void UpdateScreensSelection(){
  
  Screen.SelectionMaskUpdate(2, Selection.SelectedKeysInOrder[0]->NAME);
}
#endif