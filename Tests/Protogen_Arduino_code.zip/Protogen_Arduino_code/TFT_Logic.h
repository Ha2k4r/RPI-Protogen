#if TFTSCREEN_IS_ACTIVE
class TFTScreen {
private:
    const int colSize = 16; 
    Adafruit_ST7735 tft;
    bool LinesOcupied[4] = {0,0,0,0};
    String LineText[4] = {"","","",""};
public:
    
    TFTScreen() : tft(TFT_CS, TFT_DC, TFT_RST) {}

    Initialize() {
        SPI.begin();
        //SPI.setClockDivider(SPI_CLOCK_DIV4);
        tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);  //fuck dynamic allocation
        tft.initR(INITR_BLACKTAB);  // Try INITR_GREENTAB or INITR_REDTAB if needed
        tft.fillScreen(ST77XX_BLACK);  // Hawk tua reset that thang
        tft.setTextSize(2); //do not touch
        //tft->println("Haiiiiiii"); // Haiiiii
        tft.setSPISpeed(115200); // speed
        tft.setTextColor(ST77XX_WHITE); //what else would you use?
    }

    void SelectionMaskUpdate(unsigned short Line, const String& text) {
        int color;
        int ErrorColor;
        //Test if this is a ClearLineOperation
        if (text.length() == 0){
          if (LinesOcupied[Line]){
            //CLEARING THE LINE
          color = ST77XX_BLACK;
          ErrorColor = ST77XX_BLACK;
          LinesOcupied[Line] = true;
          }
          else{
            return;
          }
        }
        //perform some checks to make sure the line writing goes as intended
        else{
          //ensure we dont waste time rewriting things that are already there
          if (LinesOcupied[Line]){if(LineText[Line] == text){return;}};
          LineText[Line] = text;
          color = ST77XX_RED;
          ErrorColor = ST77XX_RED;
        }
        //write to the lines!!!!
        switch (Line) {
          case 1:
            tft.setCursor(1, 1);
            tft.fillRect(0, 0, tft.width(), colSize, color); 
            if (text.length() != 0){
              tft.println(text);
              LinesOcupied[Line] = true;
            }
            break;
          case 2:
            
            tft.setCursor(1, 18);
            tft.fillRect(0, colSize+1, tft.width(), colSize, color);
            if (text.length() != 0){
              tft.println(text);
              LinesOcupied[Line] = true;
            }
             
            break;
          case 3:
            
            tft.setCursor(1, colSize*2+3);
            tft.fillRect(0, colSize*2+2, tft.width(), colSize, color);
            if (text.length() != 0){
              tft.println(text);
              LinesOcupied[Line] = true;
            }
            
            break;
          case 4:
            
            tft.setCursor(1, colSize*3+4);
            tft.fillRect(0, colSize*3+3, tft.width(), colSize, color);
            if (text.length() != 0){
              tft.println(text);
              LinesOcupied[Line] = true;
            }
            
            break;
          default:
            
            tft.setCursor(1, 69);
            tft.fillRect(0, 68, tft.width(), colSize, ErrorColor);
            tft.println("ERROR");  // Indicate an invalid selection
            
            break;
        }
    }
};

#endif
