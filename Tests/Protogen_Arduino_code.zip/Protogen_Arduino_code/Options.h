#ifndef CONFIG_H
#define CONFIG_H
#include "Sending.h"
KEY ValidNouns[] = {{"Matrix", 1,}, {"Face",2}}; //change for different Object options
KEY MatrixVerb[] = {{"Brightness", 1}, {"ENDL",0}};
KEY FaceVerb[] {{"Expression", 1}, {"ColorMap", 2}, {"Time Btwn Blinks", 3}};


//All this is changable to the users wants
//Depending on your setup or wants you may want to enable or disable features
#define BUZZER_IS_ACTIVE false 
#define TFTSCREEN_IS_ACTIVE true
#define INACTIVITY_TIMEOUT_IS_ACTIVE true //not implemented


//PIns
#define NounButtonPin   2
#define VerbButtonPin   3
#define AdverbButtonPin 4
#define SENDButtonPin   5

#define ENCODER_CLK 9   // CLK Pin (D9)
#define ENCODER_DT 10   // DT Pin (D10)
#define ENCODER_SW 12   // Switch Button (D12)
#define MAX_ENCODER_POS 32767
#define MIN_ENCODER_POS -32768 // i think these are the right numbers but i have yet to test
#define DEBOUNCE_TIME 5  // Debounce time in milliseconds
#define LONG_PRESS_TIME 1000  // Time threshold for a long press (in milliseconds) NOT IMPLEMENTED kinda

//Still pins but optimized this time lol
#if TFTSCREEN_IS_ACTIVE
  #define TFT_CS  8
  #define TFT_DC  6
  #define TFT_RST 7
#endif
#if INACTIVITY_TIMEOUT_IS_ACTIVE
  #define SECONDS_TILLT_TIMOUT 10
#endif

#if BUZZER_IS_ACTIVE
  #define buzzerPin      A0

  const int ErrorBuzztime=       500; //milliseconds the buzzer should activate for when error
  const int SinglePressBuzztime= 20;
  const int DoublePressBuzztime= 50;
  const int ErrorPitch=          900;
  const int SingleBuzzPitch=     200;
  const int DoubleBuzzPitch=     400;
  
  int* buzztime = NULL;
  bool IsBuzzing = false;
  unsigned long TimeSinceBuzzerActivated = 0; //Leave alone
#endif


#define ButtonPressDelayRemove 300 // the time it takes to remove (quarter of a second)
#define debounceDelay 50    // the button noise debounce time; increase if the output flickers (it wont)
//just some shared values ignore (the sUuuper globals)

unsigned short updatedValues[4] = {0,0,0,0};

#endif




