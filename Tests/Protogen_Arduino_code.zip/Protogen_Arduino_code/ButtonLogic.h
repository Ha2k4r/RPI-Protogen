#include "Options.h"
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>

#if BUZZER_IS_ACTIVE
void buzzerTick(){
  if (IsBuzzing){
  if (millis() - TimeSinceBuzzerActivated > *buzztime){
    noTone(buzzerPin);
    TimeSinceBuzzerActivated=0;
    IsBuzzing = false;
  }
  }
}
#endif

class ArbitraryButton{
    private: 
      const int UNIQUENUMBER; //for updating the updatedValues[] list
      //Well this is obvious aint it?
      const int PIN;
      bool buttonState = HIGH;
      //Noise filtering
      unsigned long lastDebounceTime = 0;  // the last time the output PIN was toggled
      int lastButtonState = HIGH;          // the previous reading from the input PIN
      //Double Press detection
      int ButtonPressCounter = 0;
      
      unsigned long lastPressTime = 0;
      //Single Press Detection (SO WE REALLLLY CAN MAKE SURE THIS PRESS IS REAL)
      bool lastPressWasSinglePress = false;
      unsigned long lastDepressTime = 0;
    public:

      //Function to update button depending on if it has been pressed (with debounce detection)
      void ReadButtonInput(){
        const int reading = digitalRead(this->PIN);
        // If the switch changed, due to noise or pressing:
        if (reading != this->lastButtonState) {
          // reset the debouncing timer
          this->lastDebounceTime = millis();
        }
        //check the if the last time it was pressed is larger than our arbatrary debounce filter delay
        ///to ensure noise filtering
        unsigned long currentTime = millis();
        unsigned long elapsedTime = currentTime - this->lastDebounceTime; // In miliseconds

        

        if(elapsedTime > debounceDelay){
          //Actual logic for when the button has been changed 
          if (reading != this->buttonState){
            this->buttonState = reading;
            
            if (buttonState == LOW){
              //DoublePressDetection
              if (currentTime - lastPressTime > ButtonPressDelayRemove){
                this->ButtonPressCounter = 0;
              }
              this->lastPressTime = currentTime;
              this->ButtonPressCounter++;
              if (this->ButtonPressCounter == 2){
                #if BUZZER_IS_ACTIVE
                tone(buzzerPin, DoubleBuzzPitch);
                TimeSinceBuzzerActivated = currentTime;
                IsBuzzing = true;
                buzztime = &DoublePressBuzztime;
                #endif
                updatedValues[UNIQUENUMBER] = 2;
                //Serial.println("              Button DOUUBLE PRESSED!");
              }
              else if (this->ButtonPressCounter > 2){
                #if BUZZER_IS_ACTIVE
                tone(buzzerPin, ErrorPitch); // A4
                TimeSinceBuzzerActivated = currentTime;
                IsBuzzing = true;
                buzztime = &ErrorBuzztime;
                #endif
                updatedValues[UNIQUENUMBER] = 3;
                //Serial.println("              Button MULTI PRESSED Stop spamming! (we can assume you ment a double press) ");
              }
            }
            else { //it has changed and is being depressed now me frfr
              this->lastDepressTime = currentTime;
              if (this->ButtonPressCounter==1){
                lastPressWasSinglePress = true;
              }
              else {
                lastPressWasSinglePress = false;
              }
            }
          }
        }
        //check if it has been depressed long enough to warent calling it a single button press
        if ((currentTime - this->lastDepressTime > ButtonPressDelayRemove ) && lastPressWasSinglePress && this->ButtonPressCounter == 1)
          { 
          this->lastDepressTime = currentTime;
          #if BUZZER_IS_ACTIVE
            tone(buzzerPin, SingleBuzzPitch); // A4
            TimeSinceBuzzerActivated = currentTime;
            IsBuzzing = true;
            buzztime = &SinglePressBuzztime;
          #endif
          updatedValues[UNIQUENUMBER] = 1;
          //Serial.println("              Button Confirmed as single pressed!");
          lastPressWasSinglePress = false;
        }
        this->lastButtonState = reading;
      } 
      

      //Constructer
      ArbitraryButton(const int& pin, const int& uniquenumber): PIN(pin), UNIQUENUMBER(uniquenumber)
      {
        pinMode(this->PIN, INPUT_PULLUP);
      }
};

