#include "Options.h"
class RotaryEncoder {
private:
    int pinA, pinB, buttonPin;
    int position;
    int lastStateA;
    int lastButtonState;
    unsigned long lastDebounceTime;
    unsigned long buttonPressTime;
    void (*onPressCallback)();
    void (*onLongPressCallback)();
    void (*onRotateCallback)(char);
    bool skipInput = false;
public:
    RotaryEncoder(int clk, int dt, int sw, 
                  void (*pressCallback)(), 
                  void (*longPressCallback)(), 
                  void (*onRotateCallback)(char)) 
                    : pinA(clk), pinB(dt), buttonPin(sw), 
                      onPressCallback(pressCallback), 
                      onLongPressCallback(longPressCallback), 
                      onRotateCallback(onRotateCallback) 
      {
        position = 0;
        lastStateA = LOW;
        lastButtonState = HIGH;  // Assuming pull-up resistor
        lastDebounceTime = 0;
        buttonPressTime = 0;
        onPressCallback;
        onLongPressCallback;
        onRotateCallback;
    }

    void begin() {
        pinMode(pinA, INPUT_PULLUP);
        pinMode(pinB, INPUT_PULLUP);
        pinMode(buttonPin, INPUT_PULLUP);
        lastStateA = digitalRead(pinA);
    }




    void setOnPress(void (*callback)()) {
        onPressCallback = callback;
    }

    void setOnLongPress(void (*callback)()) {
        onLongPressCallback = callback;
    }

    void update() {
        int stateA = digitalRead(pinA);
        int stateB = digitalRead(pinB);
        unsigned long now = millis();
  
        // Rotary Encoder Logic (Polling with Debounce)
        if ((now - lastDebounceTime) > DEBOUNCE_TIME) {
            if (stateA != lastStateA) {
              if (!skipInput){
                if (stateB != stateA) onRotateCallback('A'); //add
                else onRotateCallback('S'); //subtract

                lastDebounceTime = now;
                skipInput = true;
              }
              else{
                skipInput = false;
              }
            }
        }

        lastStateA = stateA;

        // Button Press Handling (Debounced)
        int buttonState = digitalRead(buttonPin);
        if (buttonState == LOW && lastButtonState == HIGH) {
            delay(DEBOUNCE_TIME); // Debounce
            if (digitalRead(buttonPin) == LOW) {
                buttonPressTime = millis(); // Start tracking press time
                if (onPressCallback) onPressCallback();
            }
        }

        // Long press detection
        if (buttonState == LOW && (millis() - buttonPressTime) > LONG_PRESS_TIME) {
            if (onLongPressCallback) onLongPressCallback();
        }

        lastButtonState = buttonState;
    }
};

void onPress() {
    Serial.println("Encoder Button Pressed!");
}

void onLongPress() {
    Serial.println("Encoder Button Long Pressed!");
}